import io, json, csv, sqlite3
from datetime import datetime, timezone
from pathlib import Path
import numpy as np, pandas as pd, joblib
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel, Field
from app.train import FEATURES, MODEL_DIR
from app.train import train as train_models
from app.train import synthetic_data

BASE=Path(__file__).resolve().parents[1]
DB=BASE/'sentinelai.db'
app=FastAPI(title='SentinelAI API',version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=['http://localhost:5173','http://127.0.0.1:5173'],allow_methods=['*'],allow_headers=['*'])

class Record(BaseModel):
    duration:float=Field(ge=0); total_fwd_packets:float=Field(ge=0); total_bwd_packets:float=Field(ge=0)
    total_fwd_bytes:float=Field(ge=0); total_bwd_bytes:float=Field(ge=0); flow_bytes_per_sec:float=Field(ge=0)
    flow_packets_per_sec:float=Field(ge=0); fwd_packet_length_mean:float=Field(ge=0); bwd_packet_length_mean:float=Field(ge=0)
    syn_flag_count:float=Field(ge=0); ack_flag_count:float=Field(ge=0); flow_iat_mean:float=Field(ge=0)
class Records(BaseModel): records:list[Record]=Field(min_length=1,max_length=5000)
class Lab(BaseModel): count:int=Field(default=20,ge=1,le=200); seed:int=42
class Status(BaseModel): status:str

def db():
    BASE.mkdir(exist_ok=True,parents=True)
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY,timestamp TEXT,prediction TEXT,anomaly INTEGER,risk_score INTEGER,severity TEXT,status TEXT,explanation TEXT,features TEXT)")
    return c

def models():
    if not (MODEL_DIR/'classifier.joblib').exists() or not (MODEL_DIR/'anomaly.joblib').exists(): train_models(demo=True)
    return joblib.load(MODEL_DIR/'classifier.joblib'),joblib.load(MODEL_DIR/'anomaly.joblib')

def score(rec):
    clf,anom=models(); row={k:float(rec.get(k,0) or 0) for k in FEATURES}; x=pd.DataFrame([row],columns=FEATURES).replace([np.inf,-np.inf],np.nan)
    prob=float(clf.predict_proba(x)[0][1]); pred='attack' if prob>=.5 else 'normal'; anomaly=anom.predict(x)[0]==-1
    risk=int(round(max(prob,.65 if anomaly else 0)*100)); severity='critical' if risk>=90 else 'high' if risk>=70 else 'medium' if risk>=40 else 'low'
    why=[]
    if row['syn_flag_count']>=8: why.append('Elevated SYN flag count')
    if row['total_fwd_packets']>30 and row['total_bwd_packets']<4: why.append('Forward/backward packet imbalance')
    if row['flow_packets_per_sec']>1000: why.append('High packet rate')
    if row['flow_bytes_per_sec']>1_000_000: why.append('High byte rate')
    if anomaly: why.append('Flow differs from learned baseline')
    if pred=='attack': why.append('Classifier assigned attack class')
    if not why: why=['No configured high-signal rule fired; review context']
    ts=datetime.now(timezone.utc).isoformat(); c=db()
    cur=c.execute("INSERT INTO incidents(timestamp,prediction,anomaly,risk_score,severity,status,explanation,features) VALUES(?,?,?,?,?,'new',?,?)",(ts,pred,int(anomaly),risk,severity,json.dumps(why[:5]),json.dumps(row)))
    iid=cur.lastrowid; c.commit(); c.close()
    return {'incident_id':iid,'timestamp':ts,'prediction':pred,'anomaly':anomaly,'risk_score':risk,'severity':severity,'status':'new','explanation':why[:5],'features':row}

def all_incidents(limit=100):
    c=db(); rows=c.execute('SELECT * FROM incidents ORDER BY id DESC LIMIT ?', (limit,)).fetchall(); c.close()
    return [{'id':r['id'],'timestamp':r['timestamp'],'prediction':r['prediction'],'anomaly':bool(r['anomaly']),'risk_score':r['risk_score'],'severity':r['severity'],'status':r['status'],'explanation':json.loads(r['explanation']),'features':json.loads(r['features'])} for r in rows]

@app.get('/api/health')
def health(): return {'status':'ok'}
@app.get('/api/incidents')
def incidents(limit:int=100):
    if not 1<=limit<=500: raise HTTPException(400,'limit must be between 1 and 500')
    return all_incidents(limit)
@app.get('/api/metrics')
def metrics():
    rows=all_incidents(500)
    return {'total':len(rows),'attacks':sum(r['prediction']=='attack' for r in rows),'anomalies':sum(r['anomaly'] for r in rows),'open_incidents':sum(r['status'] in ('new','investigating') for r in rows),'average_risk':round(sum(r['risk_score'] for r in rows)/len(rows),1) if rows else 0}
@app.post('/api/analyze/records')
def analyze(req:Records): return {'count':len(req.records),'results':[score(r.model_dump()) for r in req.records]}
@app.post('/api/lab/generate')
def lab(req:Lab):
    rng=np.random.default_rng(req.seed); records=[]
    for i in range(req.count):
        bad=i%3==0; d=float(rng.lognormal(2 if bad else 5,.7)); f=int(rng.poisson(45 if bad else 10)+1); b=int(rng.poisson(1 if bad else 8))
        fm=float(np.clip(rng.normal(100 if bad else 450,100),10,1500)); bm=float(np.clip(rng.normal(70 if bad else 500,100),0,1500)); fb=f*fm; bb=b*bm; sec=max(d/1e6,.0001)
        records.append(dict(duration=d,total_fwd_packets=f,total_bwd_packets=b,total_fwd_bytes=fb,total_bwd_bytes=bb,flow_bytes_per_sec=(fb+bb)/sec,flow_packets_per_sec=(f+b)/sec,fwd_packet_length_mean=fm,bwd_packet_length_mean=bm,syn_flag_count=int(rng.poisson(12 if bad else 1)),ack_flag_count=int(rng.poisson(2 if bad else 10)),flow_iat_mean=d/max(f+b,1)))
    return {'mode':'synthetic_local_demo','count':len(records),'results':[score(r) for r in records]}
@app.post('/api/analyze/csv')
async def csv_upload(file:UploadFile=File(...)):
    if not file.filename or not file.filename.lower().endswith('.csv'): raise HTTPException(400,'Upload a CSV file')
    data=await file.read()
    if len(data)>10*1024*1024: raise HTTPException(413,'CSV limit is 10 MB')
    try: df=pd.read_csv(io.BytesIO(data))
    except Exception as e: raise HTTPException(400,f'Cannot read CSV: {e}')
    df.columns=[str(x).strip().lower().replace(' ','_') for x in df.columns]
    missing=[x for x in FEATURES if x not in df.columns]
    if missing: raise HTTPException(400,f'Missing columns: {missing}')
    if len(df)>5000: raise HTTPException(413,'At most 5000 rows per upload')
    results=[]
    for _,r in df[FEATURES].iterrows():
        try: rec={k:float(v) for k,v in r.to_dict().items()}
        except (TypeError,ValueError): raise HTTPException(400,'Features must be numeric')
        if any(not np.isfinite(v) or v<0 for v in rec.values()): raise HTTPException(400,'Features must be finite and non-negative')
        results.append(score(rec))
    return {'count':len(results),'results':results}
@app.patch('/api/incidents/{iid}')
def update(iid:int,req:Status):
    if req.status not in ('new','investigating','resolved','false_positive'): raise HTTPException(400,'Invalid status')
    c=db(); cur=c.execute('UPDATE incidents SET status=? WHERE id=?',(req.status,iid)); c.commit(); c.close()
    if not cur.rowcount: raise HTTPException(404,'Incident not found')
    return next(x for x in all_incidents(500) if x['id']==iid)
@app.get('/api/export/incidents.csv')
def export():
    out=io.StringIO(); w=csv.writer(out); w.writerow(['id','timestamp','prediction','anomaly','risk_score','severity','status','explanation','features'])
    for r in all_incidents(500): w.writerow([r['id'],r['timestamp'],r['prediction'],r['anomaly'],r['risk_score'],r['severity'],r['status'],'; '.join(r['explanation']),json.dumps(r['features'])])
    return Response(out.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=sentinelai-incidents.csv'})
