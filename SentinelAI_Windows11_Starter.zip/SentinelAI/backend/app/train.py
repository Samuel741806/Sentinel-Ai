import argparse, json
from pathlib import Path
import numpy as np, pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

ROOT=Path(__file__).resolve().parents[1]
MODEL_DIR=ROOT/'models'
FEATURES=['duration','total_fwd_packets','total_bwd_packets','total_fwd_bytes','total_bwd_bytes','flow_bytes_per_sec','flow_packets_per_sec','fwd_packet_length_mean','bwd_packet_length_mean','syn_flag_count','ack_flag_count','flow_iat_mean']

def synthetic_data(n=2500, seed=42):
    rng=np.random.default_rng(seed); rows=[]
    for y in rng.choice([0,1],n,p=[.78,.22]):
        d=float(rng.lognormal(5 if not y else 2,1)); f=int(rng.poisson(10 if not y else 35)+1); b=int(rng.poisson(8 if not y else 1))
        fm=float(np.clip(rng.normal(450 if not y else 100,150),1,1500)); bm=float(np.clip(rng.normal(500 if not y else 80,150),0,1500))
        fb=f*fm; bb=b*bm; sec=max(d/1_000_000,.0001)
        rows.append(dict(duration=d,total_fwd_packets=f,total_bwd_packets=b,total_fwd_bytes=fb,total_bwd_bytes=bb,flow_bytes_per_sec=(fb+bb)/sec,flow_packets_per_sec=(f+b)/sec,fwd_packet_length_mean=fm,bwd_packet_length_mean=bm,syn_flag_count=int(rng.poisson(12 if y else 1)),ack_flag_count=int(rng.poisson(2 if y else 10)),flow_iat_mean=d/max(f+b,1),label=int(y)))
    return pd.DataFrame(rows)

def train(csv=None,demo=False):
    MODEL_DIR.mkdir(parents=True,exist_ok=True)
    if csv:
        df=pd.read_csv(csv); df.columns=[str(c).strip().lower().replace(' ','_') for c in df.columns]
        missing=[c for c in FEATURES+['label'] if c not in df.columns]
        if missing: raise ValueError(f'Missing columns: {missing}')
        df=df[FEATURES+['label']].copy()
        df['label']=df['label'].astype(str).str.lower().map(lambda x: 0 if x in ('0','normal','benign','false','none') else 1)
    elif demo: df=synthetic_data()
    else: raise ValueError('Use --demo or --csv PATH')
    X=df[FEATURES].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan); y=df.label.astype(int)
    if y.nunique()<2: raise ValueError('Dataset needs both normal and attack labels')
    xt,xv,yt,yv=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
    clf=Pipeline([('imputer',SimpleImputer(strategy='median')),('model',RandomForestClassifier(n_estimators=150,class_weight='balanced',random_state=42,n_jobs=-1))])
    clf.fit(xt,yt); pred=clf.predict(xv)
    anomaly=Pipeline([('imputer',SimpleImputer(strategy='median')),('model',IsolationForest(n_estimators=120,contamination=.08,random_state=42))])
    normal=xt.loc[yt==0]; anomaly.fit(normal if len(normal) else xt)
    joblib.dump(clf,MODEL_DIR/'classifier.joblib'); joblib.dump(anomaly,MODEL_DIR/'anomaly.joblib')
    metrics={'rows':len(df),'demo_synthetic_data':bool(demo),'report':classification_report(yv,pred,output_dict=True,zero_division=0),'confusion_matrix':confusion_matrix(yv,pred).tolist()}
    (MODEL_DIR/'metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8'); print(json.dumps(metrics,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--csv'); p.add_argument('--demo',action='store_true'); a=p.parse_args(); train(a.csv,a.demo)
