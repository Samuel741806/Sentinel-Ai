from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def sample():
 return dict(duration=1000,total_fwd_packets=12,total_bwd_packets=8,total_fwd_bytes=4000,total_bwd_bytes=3000,flow_bytes_per_sec=7000,flow_packets_per_sec=20,fwd_packet_length_mean=333,bwd_packet_length_mean=375,syn_flag_count=1,ack_flag_count=10,flow_iat_mean=50)
def test_health(): assert client.get('/api/health').json()['status']=='ok'
def test_analyze(): 
 r=client.post('/api/analyze/records',json={'records':[sample()]}); assert r.status_code==200
 x=r.json()['results'][0]; assert x['prediction'] in ('normal','attack') and 0<=x['risk_score']<=100
def test_lab(): assert client.post('/api/lab/generate',json={'count':3}).json()['count']==3
def test_negative_rejected():
 x=sample(); x['duration']=-1
 assert client.post('/api/analyze/records',json={'records':[x]}).status_code==422
