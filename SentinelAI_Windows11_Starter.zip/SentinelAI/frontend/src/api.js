const B=import.meta.env.VITE_API_BASE||'http://127.0.0.1:8000';
async function req(p,o={}){const r=await fetch(B+p,o);if(!r.ok){let m=`Request failed (${r.status})`;try{m=(await r.json()).detail||m}catch{}throw Error(m)}return r}
export const metrics=async()=>(await req('/api/metrics')).json();
export const incidents=async()=>(await req('/api/incidents?limit=100')).json();
export const lab=async()=>(await req('/api/lab/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({count:20,seed:Math.floor(Math.random()*100000)})})).json();
export async function upload(file){let f=new FormData();f.append('file',file);return(await req('/api/analyze/csv',{method:'POST',body:f})).json()}
export const update=async(id,status)=>(await req(`/api/incidents/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})})).json();
export const exportURL=()=>B+'/api/export/incidents.csv';
