# SentinelAI — React + FastAPI final-year project

Educational flow-based network threat detection MVP. It includes a Random Forest classifier, Isolation Forest anomaly detector, SQLite incident history, CSV upload, synthetic lab generator, React dashboard, and tests.

## Windows 11
Requirements: Python 3.11+ and Node.js 20+.

Backend PowerShell:
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m app.train --demo
uvicorn app.main:app --reload
```
If activation is blocked: `Set-ExecutionPolicy -Scope Process Bypass`. API docs: http://127.0.0.1:8000/docs

Frontend in another terminal:
```powershell
cd frontend
npm install
npm run dev
```
Open http://localhost:5173.

## CSV schema
The upload expects numeric columns: `duration,total_fwd_packets,total_bwd_packets,total_fwd_bytes,total_bwd_bytes,flow_bytes_per_sec,flow_packets_per_sec,fwd_packet_length_mean,bwd_packet_length_mean,syn_flag_count,ack_flag_count,flow_iat_mean`. Training CSVs also need `label`. Labels `normal`, `benign`, and `0` mean normal; all others mean attack. Map your chosen dataset's column names before use and check dataset terms/license.

Train a labeled dataset:
`python -m app.train --csv path\to\dataset.csv`

## Safety and limitations
The lab button generates synthetic data locally. This starter does not capture packets, send traffic, or block hosts. Only analyze networks you own or are explicitly authorized to test. The default model is trained on synthetic data and is only a software demo; evaluate on held-out real data before making accuracy claims. The risk score is a prioritization score, not a calibrated probability.
